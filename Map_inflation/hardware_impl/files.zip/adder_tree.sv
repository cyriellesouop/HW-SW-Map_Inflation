`timescale 1ns/1ps
// =============================================================================
// adder_tree.sv  —  Fixed (Issue 2)
//
// ISSUE 2 FIX — Linear ripple-chain replaced with registered binary adder tree:
//
//   Original Stage 2 was a single combinational always @(*) loop:
//       for (i=0; i<KERNEL_SIZE; i++) full_sum = full_sum + products[i];
//   This synthesises as a serial K-level adder chain (critical path = O(K)),
//   limiting Fmax as the kernel grows.
//
//   Fixed: LEVELS = ceil(log2(KERNEL_SIZE)) registered pipeline stages.
//   Each stage pairs adjacent partial sums, halving the operand count.
//   Critical path per stage = one 2-input adder = O(1), regardless of K.
//
//   Example  KERNEL_SIZE = 3  (LEVELS = 2):
//     Stage-0 register : product[0], product[1], product[2]
//     Level-1 register : sum_01 = p[0]+p[1],  pass_2 = p[2]
//     Level-2 register : final  = sum_01 + pass_2   <-- FIFO input
//
//   Total pipeline latency  : LEVELS + 1 register stages (was 2 + 1 with FIFO)
//   Critical path per stage : 1 × 2-input addition    (was K-input chain)
// =============================================================================

module adder_tree #(
    parameter KERNEL_SIZE  = 3,
    parameter DATA_WIDTH   = 8,
    parameter WEIGHT_WIDTH = 8,
    parameter DEPTH        = 8,
    parameter PTR_WIDTH    = 3
)(
    input  clk,
    input  rstn,

    // Write interface (from PE row)
    input  adder_en,
    input  [(DATA_WIDTH + WEIGHT_WIDTH) * KERNEL_SIZE - 1 : 0] adder_dataIn,

    // AXI-Stream Master Interface (to downstream FIFO / crossbar)
    input  m_axis_tready,
    output [(DATA_WIDTH + WEIGHT_WIDTH + $clog2(KERNEL_SIZE)) - 1 : 0] m_axis_tdata,
    output m_axis_tvalid
);

    // -------------------------------------------------------------------------
    // Local parameters
    // -------------------------------------------------------------------------
    localparam PRODUCT_WIDTH     = DATA_WIDTH + WEIGHT_WIDTH;
    localparam PARTIAL_SUM_WIDTH = PRODUCT_WIDTH + $clog2(KERNEL_SIZE);
    localparam FINAL_OUT_WIDTH   = PARTIAL_SUM_WIDTH;

    // Number of registered pipeline levels in the binary tree.
    // $clog2(1)=0, so guard against KERNEL_SIZE=1 (trivial pass-through).
    localparam int LEVELS = (KERNEL_SIZE > 1) ? $clog2(KERNEL_SIZE) : 1;

    // -------------------------------------------------------------------------
    // Pipeline storage
    //   tree[stage][element_index]
    //   stage 0        : registered inputs (KERNEL_SIZE elements, PRODUCT_WIDTH bits)
    //   stage 1..LEVELS: binary-paired partial sums (PARTIAL_SUM_WIDTH bits each)
    //
    // Upper stages have fewer valid elements; unused slots are don't-care.
    // -------------------------------------------------------------------------
    logic [PARTIAL_SUM_WIDTH-1:0] tree    [0:LEVELS][0:KERNEL_SIZE-1];
    logic                          tree_en [0:LEVELS];

    // -------------------------------------------------------------------------
    // Back-pressure: pipeline stalls when FIFO cannot accept output.
    // tree[LEVELS][0] is the final sum; it drives the FIFO slave port directly
    // (no extra output register needed — tree[LEVELS] is already registered).
    // -------------------------------------------------------------------------
    wire fifo_s_tready;
    wire pipe_en = fifo_s_tready || !tree_en[LEVELS];

    // Drive FIFO slave directly from the last tree stage (saves one register)
    wire                     fifo_s_tvalid = tree_en[LEVELS];
    wire [FINAL_OUT_WIDTH-1:0] fifo_s_tdata  = tree[LEVELS][0][FINAL_OUT_WIDTH-1:0];

    // -------------------------------------------------------------------------
    // Stage 0: Register raw product inputs
    // -------------------------------------------------------------------------
    always_ff @(posedge clk) begin
        if (!rstn) begin
            tree_en[0] <= 1'b0;
            for (int j = 0; j < KERNEL_SIZE; j++)
                tree[0][j] <= '0;
        end else if (pipe_en) begin
            tree_en[0] <= adder_en;
            for (int j = 0; j < KERNEL_SIZE; j++) begin
                tree[0][j] <= adder_en
                    ? PARTIAL_SUM_WIDTH'(adder_dataIn[j*PRODUCT_WIDTH +: PRODUCT_WIDTH])
                    : '0;
            end
        end
    end

    // -------------------------------------------------------------------------
    // Levels 1 .. LEVELS  (generated binary tree)
    //
    // At each level l, the number of inputs from the previous stage is:
    //   IN_COUNT  = ceil( KERNEL_SIZE / 2^l )
    // The number of outputs produced is:
    //   OUT_COUNT = ceil( IN_COUNT / 2 )
    //
    // Each output pairs two adjacent inputs. If IN_COUNT is odd, the last
    // element is passed through unchanged (no addition needed).
    // -------------------------------------------------------------------------
    generate
        for (genvar l = 0; l < LEVELS; l++) begin : gen_tree_level

            // How many elements enter this level (from tree[l])
            localparam int IN_COUNT  = (KERNEL_SIZE + (1 << l) - 1) / (1 << l);
            // How many partial sums this level produces (into tree[l+1])
            localparam int OUT_COUNT = (IN_COUNT + 1) / 2;

            always_ff @(posedge clk) begin
                if (!rstn) begin
                    tree_en[l+1] <= 1'b0;
                    for (int k = 0; k < KERNEL_SIZE; k++)
                        tree[l+1][k] <= '0;
                end else if (pipe_en) begin
                    // Propagate the valid flag
                    tree_en[l+1] <= tree_en[l];

                    for (int k = 0; k < OUT_COUNT; k++) begin
                        if (2*k + 1 < IN_COUNT) begin
                            // Pair: add two adjacent elements
                            tree[l+1][k] <= tree[l][2*k] + tree[l][2*k+1];
                        end else begin
                            // Odd last element: pass through without addition
                            tree[l+1][k] <= tree[l][2*k];
                        end
                    end
                end
            end

        end
    endgenerate

    // -------------------------------------------------------------------------
    // Output FIFO (AXI-Stream wrapper, unchanged from original)
    // -------------------------------------------------------------------------
    fifo_axis #(
        .DATAWIDTH (FINAL_OUT_WIDTH),
        .DEPTH     (DEPTH),
        .PTR_WIDTH (PTR_WIDTH)
    ) fifo_axis_inst (
        .clk      (clk),
        .rstn     (rstn),
        .s_tvalid (fifo_s_tvalid),
        .s_tdata  (fifo_s_tdata),
        .s_tready (fifo_s_tready),
        .m_tready (m_axis_tready),
        .m_tdata  (m_axis_tdata),
        .m_tvalid (m_axis_tvalid)
    );

endmodule
