`timescale 1ns/1ps
// =============================================================================
// fifo.v  —  Fixed (Issue 4)
//
// ISSUE 4 FIX — Registered-read output replaced with fall-through (show-ahead):
//
//   Original: dataOut was registered (dataOut <= MEM[rd_addr] inside always@clk).
//   This meant the consumer had to assert RD on cycle N and could only use
//   the data on cycle N+1 — a mandatory 1-cycle read latency ADDED ON TOP OF
//   the write latency.  With multiple FIFOs in the critical path (adder_tree,
//   axis_unpack_data, unpacker_module) this compounded to 5+ wasted cycles.
//
//   Fixed: dataOut is driven COMBINATIONALLY from MEM[rd_addr].
//   As soon as a location is written (~empty), its data is visible on dataOut
//   in the same cycle.  The consumer can register it at its own boundary.
//   The read pointer still advances on RD && ~empty (unchanged).
//
//   Timing note:
//     • Write path : data appears in MEM one cycle after WR (registered write —
//       unchanged).  Fall-through removes only the EXTRA read register, not the
//       write register.  First-word latency is therefore 1 cycle (write to read),
//       down from 2 cycles in the original.
//     • This implementation uses distributed RAM (LUT-based), which supports
//       asynchronous reads.  For depths requiring block RAM (DEPTH > ~64),
//       add a one-entry output register (skid buffer) after this FIFO to
//       re-register the combinational output.
// =============================================================================

module fifo #(
    parameter DATAWIDTH = 8,
    parameter DEPTH     = 4,
    parameter PTR_WIDTH = 2
)(
    input  clk,
    input  rstn,

    // Write interface
    input              WR,
    input  [DATAWIDTH-1:0] dataIn,
    output             full,

    // Read interface
    input              RD,
    output [DATAWIDTH-1:0] dataOut,   // combinational — changed from reg
    output             empty
);

    reg [PTR_WIDTH-1:0] wr_addr;
    reg [PTR_WIDTH-1:0] rd_addr;
    reg                 wr_cnt;
    reg                 rd_cnt;

    reg [DATAWIDTH-1:0] MEM [DEPTH-1:0];

    // -------------------------------------------------------------------------
    // Write interface (unchanged)
    // -------------------------------------------------------------------------
    always @(posedge clk) begin
        if (!rstn) begin
            wr_cnt  <= 1'b0;
            wr_addr <= '0;
        end else begin
            if (WR && ~full) begin
                MEM[wr_addr] <= dataIn;
                if (wr_addr == DEPTH - 1) begin
                    wr_addr <= '0;
                    wr_cnt  <= ~wr_cnt;
                end else begin
                    wr_addr <= wr_addr + 1'b1;
                end
            end
        end
    end

    // -------------------------------------------------------------------------
    // Read interface — pointer only, no output register
    // -------------------------------------------------------------------------
    always @(posedge clk) begin
        if (!rstn) begin
            rd_cnt  <= 1'b0;
            rd_addr <= '0;
        end else begin
            if (RD && ~empty) begin
                // Advance pointer; data is already on dataOut this cycle
                if (rd_addr == DEPTH - 1) begin
                    rd_addr <= '0;
                    rd_cnt  <= ~rd_cnt;
                end else begin
                    rd_addr <= rd_addr + 1'b1;
                end
            end
        end
    end

    // -------------------------------------------------------------------------
    // Fall-through output: always present when ~empty
    //   The consumer must gate on (m_tvalid = ~empty) before using dataOut.
    // -------------------------------------------------------------------------
    assign dataOut = MEM[rd_addr];

    // -------------------------------------------------------------------------
    // Full / Empty flags (unchanged)
    // -------------------------------------------------------------------------
    assign empty = (wr_addr == rd_addr) && (wr_cnt == rd_cnt);
    assign full  = (wr_addr == rd_addr) && (wr_cnt != rd_cnt);

endmodule
